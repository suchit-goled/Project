import productService from "../services/product.service.js";
import ApiResponse from "../utils/apiResponse.js";

class ProductController {

    async getProducts(req, res, next) {

        try {

            const products = await productService.getProducts(req.query);

            return ApiResponse.success(
                res,
                products,
                "Products fetched successfully."
            );

        } catch (error) {

            next(error);

        }

    }

    async getFeaturedProducts(req, res, next) {

        try {

            const featuredProducts =
                await productService.getFeaturedProducts();

            return ApiResponse.success(
                res,
                featuredProducts,
                "Featured products fetched successfully."
            );

        } catch (error) {

            next(error);

        }

    }

    async getProductById(req, res, next) {

        try {

            const product =
                await productService.getProductById(req.params.id);

            return ApiResponse.success(
                res,
                product,
                "Product fetched successfully."
            );

        } catch (error) {

            next(error);

        }

    }

}

export default new ProductController();