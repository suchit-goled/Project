import homeRoutes from "./routes/home.routes.js";
import errorMiddleware from "./middleware/error.middleware.js";
import productRoutes from "./routes/product.routes.js";

app.use("/api/products", productRoutes);
app.use("/api/home", homeRoutes);



app.use(errorMiddleware);