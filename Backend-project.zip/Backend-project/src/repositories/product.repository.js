import Product from "../models/Product.js";

class ProductRepository {

    async getProducts(page, limit) {

        return Product.find()
            .skip((page - 1) * limit)
            .limit(limit);

    }

    async getTotalProducts() {

        return Product.countDocuments();

    }

    async getFeaturedProducts() {

        return Product.find({
            isFeatured: true,
        }).limit(5);

    }

    async getProductById(id) {

        return Product.findById(id);

    }

    async searchProducts(keyword) {

        return Product.find({

            $or: [

                {
                    product_title: {
                        $regex: keyword,
                        $options: "i",
                    },
                },

                {
                    product_category: {
                        $regex: keyword,
                        $options: "i",
                    },
                },

            ],

        });

    }

}

export default new ProductRepository();